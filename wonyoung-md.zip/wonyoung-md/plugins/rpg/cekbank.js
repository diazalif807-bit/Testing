export default {
  name: 'Cek Bank',
  command: ['cekbank', 'bankcek'],
  tags: 'Rpg Menu',
  desc: 'Menampilkan isi saldo bank',
  prefix: true,
  premium: false,

  run: async (conn, msg, { chatInfo }) => {
    const { chatId } = chatInfo;
    try {
      const { bank } = loadBank();
      const saldo = bank.saldo || 0;

      const teks = `
🏦 *BANK VITA OFFICIAL*
━━━━━━━━━━━━━━
👤 *Akun:* Bank Pusat
💳 *Saldo:* Rp ${saldo.toLocaleString('id-ID')}
━━━━━━━━━━━━━━
📌 Gunakan saldo dengan bijak!
      `.trim();

      await conn.sendMessage(chatId, { text: teks }, { quoted: msg });
    } catch {
      await conn.sendMessage(chatId, { text: '❌ Gagal menampilkan saldo bank.' }, { quoted: msg });
    }
  }
}