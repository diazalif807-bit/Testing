export default {
  name: 'antilink',
  command: ['antilink'],
  tags: 'Group Menu',
  desc: 'Fitur anti link grup',
  prefix: true,
  premium: false,

  run: async (conn, msg, {
    chatInfo,
    prefix,
    commandText,
    args
  }) => {
    const { chatId, senderId, isGroup } = chatInfo;

    if (!isGroup) 
      return conn.sendMessage(chatId, { text: 'Perintah ini hanya bisa digunakan dalam grup!' }, { quoted: msg });

    const groupData = getGc(getDB(), chatId);
    if (!groupData) 
      return conn.sendMessage(chatId, { text: `Grup belum terdaftar di database.\nGunakan *${prefix}daftargc* untuk mendaftar.` }, { quoted: msg });

    const { botAdmin, userAdmin } = await exGrup(conn, chatId, senderId);
    if (!userAdmin) return conn.sendMessage(chatId, { text: 'Kamu bukan Admin kontol bangsat' }, { quoted: msg });
    if (!botAdmin) return conn.sendMessage(chatId, { text: 'Bot bukan admin!' }, { quoted: msg });

    const input = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(input)) 
      return conn.sendMessage(chatId, { text: `Penggunaan:\n${prefix}${commandText} <on/off>` }, { quoted: msg });

    groupData.gbFilter ??= {};
    groupData.gbFilter.link ??= {};
    groupData.gbFilter.link.antilink = input === 'on';
    saveDB();

    return conn.sendMessage(chatId, { text: `Fitur antilink berhasil di-${input === 'on' ? 'aktifkan' : 'nonaktifkan'}.` }, { quoted: msg });
  }
};